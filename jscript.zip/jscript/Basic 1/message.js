function msg(){  
 alert("Hello welcome");  
}  