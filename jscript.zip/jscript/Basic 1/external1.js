function print()
{
document.write("welcome to header javascript");
}